package com.example.tallerandroidinterfaces.models

data class empleado(
    val name:String,
    val position:String
)
